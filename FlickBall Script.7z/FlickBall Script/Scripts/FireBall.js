// -----JS CODE-----

//@input SceneObject firePoint
//@input float firePower = 1
//@input Asset.ObjectPrefab ballOriginal
//@input Component.Camera camera
//@input Component.ScriptComponent scoreCounter 


// the actual ball instancing function
function createObjectFromPrefab() {
    var instanceObject = script.ballOriginal.instantiate(null);
    return instanceObject;
}
var touchStartPosition = new vec3(0, 0, 0);

var isTouching = false;
var frameCount = 0;
script.createEvent("TouchStartEvent").bind(onTouchStart);

// this function instanciate the ball at the camera fire position
function onTouchStart(e) {
    if (!isTouching) {
        newBall = createObjectFromPrefab();
        touchStartPosition = script.camera.screenSpaceToWorldSpace(e.getTouchPosition(), 10);
        script.api.makeBounce = false;
        isTouching = true;
        script.scoreCounter.api.ballIn = false;
    }
}
// updation function set up to manage visiblity if the fucked up ball
var event = script.createEvent("UpdateEvent");
event.bind(function (eventData) {
    if (isTouching) {
        frameCount += 1
        if (frameCount > 1) {
            // will make it visible when its is second frame after spawning.
            var MVisual = newBall.getComponentByIndex("", 1);
            MVisual.enabled = true;
        }
    }
});
// ball fire section| adds velocity and in the end resets every thing for the next fire.
script.createEvent("TouchEndEvent").bind(onTouchFinish);
function onTouchFinish(e) {
    if (isTouching) {
        var firDir = script.camera.screenSpaceToWorldSpace(e.getTouchPosition(), 30).sub(touchStartPosition);
        var transform = newBall.getTransform();
        var camTransform = script.firePoint.getTransform();
        var vel = script.api.velocity;
        var newScript = newBall.getComponentByIndex("", 0);
        newScript.api.setVelocity(firDir, script.firePower);
        transform.setWorldPosition(camTransform.getWorldPosition());
        newScript.api.makeBounce = true;
        isTouching = false;
        frameCount = 0;
    }
}