// -----JS CODE-----

//@input SceneObject box
var collider = [];

script.api.AddAABB = function (aabb) {
  collider.push(aabb);
}
function BoxBoxIntersect(a, b) {
  var result = (a.api.minX <= b.api.maxX && a.api.maxX >= b.api.minX) &&
    (a.api.minY <= b.api.maxY && a.api.maxY >= b.api.minY) &&
    (a.api.minZ <= b.api.maxZ && a.api.maxZ >= b.api.minZ);

  return result;
}
function CheckCollisions() {
  for (x = 0; x < collider.length; x++) {
    collider[x].api.MinMaxCalcuations();

  }

  for (x = 0; x < collider.length; x++) {
    for (y = x + 1; y < collider.length; y++) {
      var colX = collider[x];
      var colY = collider[y];

      if (BoxBoxIntersect(colX, colY)) 
      {
        if (colX.api.isTrigger) 
        {
          //     print("trigger found");
          colX.api.msgReciver.api.OnTriggerEnter(colY.api.objectName);
        }
      }
      else {
        if (colX.api.isTrigger) 
        {
          colX.api.msgReciver.api.OnTriggerExit(colY.api.objectName);
        }
      }
    }
  }
}
var event = script.createEvent("UpdateEvent");
event.bind(CheckCollisions);