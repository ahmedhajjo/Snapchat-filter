
/// Move attached Transform 1 unit up


//@input SceneObject ballHoldPoint

var velocity = script.api.velocity;
var elast = script.api.elasticity;

var transform = script.getTransform();
//var groundPos = script.ground.getTransform().getWorldPosition();
var groundPos = new vec3(0,0,0);

script.api.pos = transform.getWorldPosition();
var pos = script.api.pos;

if(script.api.makeBounce){

    if( pos.y > groundPos.y + 7)
    {
        velocity.y -= 0.2;
    }

    else
    {
        velocity.y = velocity.y * elast * -1;
        pos.y = groundPos.y + 7;
    }

    pos = pos.add(velocity);
}

else
{
    pos = script.ballHoldPoint.getTransform().getWorldPosition();
}

transform.setWorldPosition(pos);


