// -----JS CODE-----


//@input SceneObject box1
var collider = [];

script.api.AddAABB = function(aabb){
collider.push(aabb);
}

function BoxBoxIntersect(a, b) {
   var result = (a.api.minX <= b.api.maxX && a.api.maxX >= b.api.minX) &&
           (a.api.minY <= b.api.maxY && a.api.maxY >= b.api.minY) &&
           (a.api.minZ <= b.api.maxZ && a.api.maxZ >= b.api.minZ);

              return result;
           
  }
/*
  function SphereBoxintersect(sphere, box) {
    // get box closest point to sphere center by clamping
    var x = Math.max(box.minX, Math.min(sphere.x, box.maxX));
    var y = Math.max(box.minY, Math.min(sphere.y, box.maxY));
    var z = Math.max(box.minZ, Math.min(sphere.z, box.maxZ));
  
    // this is the same as isPointInsideSphere
    var distance = Math.sqrt((x - sphere.x) * (x - sphere.x) +
                             (y - sphere.y) * (y - sphere.y) +
                             (z - sphere.z) * (z - sphere.z));
    
    return distance < sphere.radius;
  }

  function SphereSphereintersect(sphere, other) {
    // we are using multiplications because it's faster than calling Math.pow
    var distance = Math.sqrt((sphere.x - other.x) * (sphere.x - other.x) +
                             (sphere.y - other.y) * (sphere.y - other.y) +
                             (sphere.z - other.z) * (sphere.z - other.z));
    return distance < (sphere.radius + other.radius);
  }
*/
  function CheckCollisions(){
      for(x = 0; x< collider.length; x++){
          collider[x].api.MinMaxCalcuations();  

      }

      for (x = 0; x < collider.length; x++){
          for(y = x+1; y <collider.length; y++){
              var colX = collider[x];
              var colY = collider[y];
              
              if (BoxBoxIntersect(colX,colY)){
               
                if(colX.api.isTrigger)
                {
                //     print("trigger found");
                    
                      colX.api.msgReciver.api.OnTriggerEnter(colY.api.objectName);

                
                }
                
         //       else print(script.box1);
              
               
              }

            else
            {
                if(colX.api.isTrigger)
                {
                    colX.api.msgReciver.api.OnTriggerExit(colY.api.objectName);
                }
            }

          }
      }
  }

  var event = script.createEvent("UpdateEvent");
  event.bind(CheckCollisions);